#include "B.h"

ClaseB::ClaseB(){
    this->numB = 2;
}

void ClaseB::setB(int nB){
    this->numB = nB;
}

int ClaseB::getB(){
    return this->numB;
}
ClaseB::~ClaseB(){};
