#include"A.h"

ClaseA::ClaseA(){
    this->numA = 1;
}
void ClaseA::SetA(int nA){
    this->numA = nA;
}
int ClaseA::getA(){
    return this->numA;
}
ClaseA::~ClaseA(){};
