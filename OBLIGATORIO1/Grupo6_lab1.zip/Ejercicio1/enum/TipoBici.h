#ifndef PAV_TIPOBICI_H
#define PAV_TIPOBICI_H
enum tipoBici {Paseo, Montania};
#endif //PAV_TIPOBICI_H
