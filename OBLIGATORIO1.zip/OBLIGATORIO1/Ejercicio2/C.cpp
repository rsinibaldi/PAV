#include "C.h"



ClaseC::ClaseC(){
    this->numC = 3;
}

void ClaseC::setC(int nC){
    this->numC = nC;
}

int ClaseC::getC(){
    return this->numC;
}

ClaseC::~ClaseC(){};
