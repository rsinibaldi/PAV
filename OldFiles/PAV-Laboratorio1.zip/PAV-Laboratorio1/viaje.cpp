#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// #include "viaje.h"
#include "viaje.h"

using namespace std;
